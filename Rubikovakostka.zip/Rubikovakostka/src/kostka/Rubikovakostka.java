
package kostka;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;




public class Rubikovakostka extends JFrame {
 

    public static void main(String[] args) {
  
   
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
              Data  a=new Data ();
            }
        });
     
            
     
     
     
    
     
            
        }
      
         
     
         
      
    }
     
     
        
     
    

